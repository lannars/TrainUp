import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Location from 'expo-location';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

const THEME = {
  background: '#0E0E12',
  card: '#1C1B29',
  accent: '#A855F7',
  accentDark: '#7C2EE6',
  text: '#FFFFFF',
  muted: '#B7B7C5',
  success: '#7EE787',
};

const PAGES = ['Dashboard', 'Treinos', 'Perfil'];
const STORAGE_KEY = '@runclub:user-name';
const RUNS_KEY = '@runclub:run-history';

const activitiesMock = [
  { id: '1', athlete: 'Luna Costa', distance: '7,4 km', pace: '5:12/km', mood: '🔥' },
  { id: '2', athlete: 'Miguel Silva', distance: '12 km', pace: '4:58/km', mood: '💨' },
  { id: '3', athlete: 'Marina Lopes', distance: '5 km', pace: '5:40/km', mood: '✨' },
];

const racesMock = [
  { id: 'r1', title: 'Night Run SP', distance: '10 km', date: '12 Dez' },
  { id: 'r2', title: 'Half Marathon Rio', distance: '21 km', date: '08 Fev' },
];

const trainingSessions = [
  { id: 't1', title: 'Tempo Run', focus: 'Ritmo sustentado', details: '6 km • Pace 4:55/km', duration: '35m', icon: '⚡' },
  { id: 't2', title: 'Longão progressivo', focus: 'Base aeróbica', details: '15 km • Pace 5:40→5:10', duration: '1h32', icon: '🌀' },
  { id: 't3', title: 'Intervalados curtos', focus: 'Velocidade', details: '10 x 400m • Pace 4:20/km', duration: '42m', icon: '🎯' },
];

const communityRoutes = [
  { id: 'c1', name: 'Circuito Lago Azul', distance: '8 km', difficulty: 'Moderado' },
  { id: 'c2', name: 'Serra do Japi Trail', distance: '12 km', difficulty: 'Avançado' },
  { id: 'c3', name: 'Parque Linear', distance: '5 km', difficulty: 'Leve' },
];

const achievements = [
  { id: 'a1', title: 'Recorde 5K', detail: '24m 12s', icon: '🥇' },
  { id: 'a2', title: '100 km no mês', detail: '84% concluído', icon: '📈' },
  { id: 'a3', title: 'Sequência ativa', detail: '12 dias', icon: '🔥' },
];

const gearList = [
  { id: 'g1', name: 'Nike Pegasus 40', status: '120 km restantes' },
  { id: 'g2', name: 'Hoka Clifton 9', status: 'Novo' },
];

const profileGoals = [
  { id: 'pg1', label: '5K sub 24', progress: 72 },
  { id: 'pg2', label: 'Meia sub 2h', progress: 46 },
];

const formatInitials = (name) => {
  if (!name) return 'CM';
  const parts = name
    .split(' ')
    .filter(Boolean)
    .map((part) => part[0]?.toUpperCase());
  if (!parts.length) return 'CM';
  return parts.slice(0, 2).join('');
};

const haversineDistance = (from, to) => {
  if (!from || !to) return 0;
  const toRad = (value) => (value * Math.PI) / 180;
  const R = 6371e3;
  const lat1 = toRad(from.latitude);
  const lat2 = toRad(to.latitude);
  const deltaLat = toRad(to.latitude - from.latitude);
  const deltaLon = toRad(to.longitude - from.longitude);

  const a =
    Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(deltaLon / 2) * Math.sin(deltaLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

const formatDuration = (milliseconds = 0) => {
  const totalSeconds = Math.floor(milliseconds / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  if (hours > 0) {
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(
      seconds,
    ).padStart(2, '0')}`;
  }
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
};

const formatDistance = (meters = 0) => {
  if (!meters) return '0,00 km';
  return `${(meters / 1000).toFixed(2).replace('.', ',')} km`;
};

const formatPace = (meters = 0, milliseconds = 0) => {
  if (!meters || meters < 15 || !milliseconds) return '--';
  const pace = milliseconds / 60000 / (meters / 1000);
  const min = Math.floor(pace);
  const sec = Math.floor((pace - min) * 60);
  return `${String(min).padStart(2, '0')}:${String(sec).padStart(2, '0')}/km`;
};

const formatRunDate = (timestamp) => {
  if (!timestamp) return '--';
  const date = new Date(timestamp);
  return date.toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'short',
  });
};

export default function App() {
  const [runState, setRunState] = useState('idle');
  const [currentPage, setCurrentPage] = useState(0);
  const [userProfile, setUserProfile] = useState(null);
  const [nameInput, setNameInput] = useState('');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const [isSavingName, setIsSavingName] = useState(false);
  const [distanceMeters, setDistanceMeters] = useState(0);
  const [elapsedMs, setElapsedMs] = useState(0);
  const [lastRun, setLastRun] = useState(null);
  const [pendingRun, setPendingRun] = useState(null);
  const [runHistory, setRunHistory] = useState([]);
  const [isSavingRun, setIsSavingRun] = useState(false);
  const [historyError, setHistoryError] = useState(null);
  const [permissionStatus, setPermissionStatus] = useState('unknown');
  const [isRequestingLocation, setIsRequestingLocation] = useState(false);
  const [runError, setRunError] = useState(null);

  const timerRef = useRef(null);
  const locationWatcherRef = useRef(null);
  const lastCoordsRef = useRef(null);

  const runHint = useMemo(() => {
    if (runState === 'running') return 'Corrida em andamento, mantenha o ritmo!';
    if (lastRun) {
      return `Última corrida: ${formatDistance(lastRun.distance)} em ${formatDuration(
        lastRun.duration,
      )}`;
    }
    return 'Pressione para iniciar sua próxima corrida';
  }, [runState, lastRun]);

  const friendlyName = useMemo(() => {
    const name = userProfile?.name;
    if (!name) return 'Camila';
    return name.split(' ')[0] || name;
  }, [userProfile]);

  const profileName = userProfile?.name || 'Camila Matos';
  const avatarInitials = useMemo(() => formatInitials(userProfile?.name), [userProfile]);

  useEffect(() => {
    const loadUserProfile = async () => {
      try {
        const stored = await AsyncStorage.getItem(STORAGE_KEY);
        if (stored) {
          let parsed;
          try {
            parsed = JSON.parse(stored);
          } catch {
            parsed = { name: stored };
          }
          setUserProfile(parsed);
          setNameInput(parsed?.name || '');
          setEmailInput(parsed?.email || '');
        }
      } finally {
        setIsLoadingUser(false);
      }
    };

    loadUserProfile();
  }, []);

  useEffect(() => {
    const loadHistory = async () => {
      if (!userProfile?.email) {
        setRunHistory([]);
        return;
      }
      try {
        const stored = await AsyncStorage.getItem(RUNS_KEY);
        if (stored) {
          const parsed = JSON.parse(stored);
          setRunHistory(parsed[userProfile.email] || []);
        } else {
          setRunHistory([]);
        }
      } catch {
        setRunHistory([]);
      }
    };
    loadHistory();
  }, [userProfile?.email]);

  useEffect(() => {
    const checkPermission = async () => {
      const { status } = await Location.getForegroundPermissionsAsync();
      setPermissionStatus(status === 'granted' ? 'granted' : 'denied');
    };
    checkPermission();
  }, []);

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      if (locationWatcherRef.current) {
        locationWatcherRef.current.remove();
      }
    };
  }, []);

  const stopTracking = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (locationWatcherRef.current) {
      locationWatcherRef.current.remove();
      locationWatcherRef.current = null;
    }
    lastCoordsRef.current = null;
  };

  const startRun = async () => {
    if (runState === 'running' || isRequestingLocation) return;
    setRunError(null);

    let granted = permissionStatus === 'granted';
    if (!granted) {
      setIsRequestingLocation(true);
      const { status } = await Location.requestForegroundPermissionsAsync();
      granted = status === 'granted';
      setPermissionStatus(granted ? 'granted' : 'denied');
      setIsRequestingLocation(false);

      if (!granted) {
        setRunError('Precisamos da sua localização para medir a distância.');
        return;
      }
    }

    try {
      setRunState('running');
      setElapsedMs(0);
      setDistanceMeters(0);
      lastCoordsRef.current = null;

      timerRef.current = setInterval(() => {
        setElapsedMs((prev) => prev + 1000);
      }, 1000);

      locationWatcherRef.current = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.Highest,
          timeInterval: 1000,
          distanceInterval: 2,
        },
        (position) => {
          const { latitude, longitude } = position.coords;
          const point = { latitude, longitude };

          if (lastCoordsRef.current) {
            const delta = haversineDistance(lastCoordsRef.current, point);
            if (!Number.isNaN(delta)) {
              setDistanceMeters((prev) => prev + delta);
            }
          }
          lastCoordsRef.current = point;
        },
      );
    } catch (error) {
      setRunError('Não foi possível iniciar o rastreamento agora.');
      stopTracking();
      setRunState('idle');
    }
  };

  const finishRun = () => {
    if (runState !== 'running') return;
    stopTracking();
    setRunState('idle');
    setRunError(null);
    const summary = {
      id: String(Date.now()),
      distance: distanceMeters,
      duration: elapsedMs,
      endedAt: Date.now(),
    };
    setLastRun(summary);
    setPendingRun(summary);
  };

  const handleSaveRun = async () => {
    if (!userProfile?.email || !pendingRun) return;
    setHistoryError(null);
    setIsSavingRun(true);
    try {
      const stored = await AsyncStorage.getItem(RUNS_KEY);
      const parsed = stored ? JSON.parse(stored) : {};
      const existing = parsed[userProfile.email] || [];
      const nextHistory = [pendingRun, ...existing];
      parsed[userProfile.email] = nextHistory;
      await AsyncStorage.setItem(RUNS_KEY, JSON.stringify(parsed));
      setRunHistory(nextHistory);
      setPendingRun(null);
    } catch (error) {
      setHistoryError('Não foi possível salvar esta corrida.');
    } finally {
      setIsSavingRun(false);
    }
  };

  const handleLogin = async () => {
    const trimmedName = nameInput.trim();
    const trimmedEmail = emailInput.trim();
    const trimmedPassword = passwordInput.trim();
    if (!trimmedName || trimmedName.length < 2) return;
    if (!trimmedEmail || !trimmedEmail.includes('@')) return;
    if (!trimmedPassword || trimmedPassword.length < 4) return;

    try {
      setIsSavingName(true);
      const payload = {
        name: trimmedName,
        email: trimmedEmail,
        password: trimmedPassword,
      };
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
      setUserProfile(payload);
      setPasswordInput('');
    } finally {
      setIsSavingName(false);
    }
  };

  const handleLogout = async () => {
    await AsyncStorage.removeItem(STORAGE_KEY);
    setUserProfile(null);
    setNameInput('');
    setEmailInput('');
    setPasswordInput('');
    setRunHistory([]);
    setPendingRun(null);
    setCurrentPage(0);
  };

  const headerCopy = useMemo(() => {
    if (currentPage === 1) {
      return {
        title: 'Treinos guiados',
        greeting: `${friendlyName}, bora elevar o nível?`,
        subtitle: 'Selecione uma sessão e sincronize com seu relógio',
      };
    }
    if (currentPage === 2) {
      return {
        title: 'Perfil',
        greeting: profileName,
        subtitle: 'Resumo das conquistas e equipamentos',
      };
    }
    return {
      title: 'Dashboard',
      greeting: `Bom dia, ${friendlyName}`,
      subtitle: 'Pronta para atingir a meta semanal?',
    };
  }, [currentPage, friendlyName, profileName]);

  const liveStats = useMemo(() => {
    const source =
      runState === 'running'
        ? { distance: distanceMeters, duration: elapsedMs }
        : lastRun;

    return [
      { label: 'Distância', value: source ? formatDistance(source.distance) : '--' },
      { label: 'Tempo', value: source ? formatDuration(source.duration) : '--' },
      { label: 'Pace médio', value: source ? formatPace(source.distance, source.duration) : '--' },
    ];
  }, [runState, distanceMeters, elapsedMs, lastRun]);

  const currentMetrics = useMemo(
    () => ({
      distance: formatDistance(runState === 'running' ? distanceMeters : lastRun?.distance ?? 0),
      duration: formatDuration(runState === 'running' ? elapsedMs : lastRun?.duration ?? 0),
      pace: formatPace(
        runState === 'running' ? distanceMeters : lastRun?.distance ?? 0,
        runState === 'running' ? elapsedMs : lastRun?.duration ?? 0,
      ),
    }),
    [runState, distanceMeters, elapsedMs, lastRun],
  );

  const renderPageContent = () => {
    if (currentPage === 1) {
      return (
        <>
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Workouts guiados</Text>
              <Text style={styles.sectionAction}>Importar</Text>
            </View>
            {trainingSessions.map((session) => (
              <View key={session.id} style={styles.sessionCard}>
                <View style={styles.sessionIcon}>
                  <Text style={styles.sessionEmoji}>{session.icon}</Text>
                </View>
                <View style={styles.sessionInfo}>
                  <Text style={styles.sessionTitle}>{session.title}</Text>
                  <Text style={styles.sessionFocus}>{session.focus}</Text>
                  <Text style={styles.sessionDetails}>{session.details}</Text>
                </View>
                <Text style={styles.sessionDuration}>{session.duration}</Text>
              </View>
            ))}
          </View>

          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Rotas da comunidade</Text>
              <Text style={styles.sectionAction}>Explorar mapa</Text>
            </View>
            {communityRoutes.map((route) => (
              <View key={route.id} style={styles.routeCard}>
                <View>
                  <Text style={styles.routeName}>{route.name}</Text>
                  <Text style={styles.routeMeta}>{route.distance} • {route.difficulty}</Text>
                </View>
                <TouchableOpacity style={styles.secondaryButton}>
                  <Text style={styles.secondaryButtonText}>Salvar</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>

          <View style={styles.recoveryCard}>
            <View>
              <Text style={styles.recoveryTitle}>Recuperação ativa</Text>
              <Text style={styles.recoverySubtitle}>20 min bike leve + mobilidade quadril</Text>
            </View>
            <Text style={styles.recoveryHint}>Sugerido para amanhã</Text>
          </View>
        </>
      );
    }

    if (currentPage === 2) {
      return (
        <>
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Histórico de corridas</Text>
              <Text style={styles.sectionAction}>
                {runHistory.length > 0 ? `${runHistory.length} corridas` : 'Nenhuma corrida'}
              </Text>
            </View>
            {runHistory.length === 0 && (
              <Text style={styles.emptyHistoryText}>
                Salve suas corridas para montar seu histórico.
              </Text>
            )}
            {runHistory.slice(0, 4).map((run) => (
              <View key={run.id} style={styles.historyCard}>
                <View>
                  <Text style={styles.historyTitle}>{formatRunDate(run.endedAt)}</Text>
                  <Text style={styles.historyMeta}>
                    {formatDistance(run.distance)} • {formatDuration(run.duration)}
                  </Text>
                </View>
                <Text style={styles.historyPace}>{formatPace(run.distance, run.duration)}</Text>
              </View>
            ))}
          </View>

          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Conquistas</Text>
              <Text style={styles.sectionAction}>Ver todas</Text>
            </View>
            <View style={styles.achievementGrid}>
              {achievements.map((achievement) => (
                <View key={achievement.id} style={styles.achievementCard}>
                  <Text style={styles.achievementIcon}>{achievement.icon}</Text>
                  <Text style={styles.achievementTitle}>{achievement.title}</Text>
                  <Text style={styles.achievementDetail}>{achievement.detail}</Text>
                </View>
              ))}
            </View>
          </View>

          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Equipamentos</Text>
              <Text style={styles.sectionAction}>Registrar</Text>
            </View>
            {gearList.map((gear) => (
              <View key={gear.id} style={styles.gearCard}>
                <View>
                  <Text style={styles.gearName}>{gear.name}</Text>
                  <Text style={styles.gearStatus}>{gear.status}</Text>
                </View>
                <TouchableOpacity style={styles.secondaryButton}>
                  <Text style={styles.secondaryButtonText}>Atualizar</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>

          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Metas em foco</Text>
              <Text style={styles.sectionAction}>Editar</Text>
            </View>
            {profileGoals.map((goal) => (
              <View key={goal.id} style={styles.goalCard}>
                <View style={styles.goalRow}>
                  <Text style={styles.goalLabel}>{goal.label}</Text>
                  <Text style={styles.goalValue}>{goal.progress}%</Text>
                </View>
                <View style={styles.goalTrack}>
                  <View style={[styles.goalFill, { width: `${goal.progress}%` }]} />
                </View>
              </View>
            ))}
          </View>

          <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
            <Text style={styles.logoutButtonText}>Sair e trocar usuário</Text>
          </TouchableOpacity>
        </>
      );
    }

    return (
      <>
        <View style={styles.highlightCard}>
          <Text style={styles.cardLabel}>
            {runState === 'running' ? 'Corrida em andamento' : 'Modo treino livre'}
          </Text>
          <Text style={styles.cardTitle}>
            {runState === 'running' ? 'Sessão ativa' : 'Pronta para largar'}
          </Text>
          <View style={styles.highlightMetricsRow}>
            <View style={styles.metricBlock}>
              <Text style={styles.metricLabel}>Tempo</Text>
              <Text style={styles.metricValue}>{currentMetrics.duration}</Text>
            </View>
            <View style={styles.metricBlock}>
              <Text style={styles.metricLabel}>Distância</Text>
              <Text style={styles.metricValue}>{currentMetrics.distance}</Text>
            </View>
            <View style={styles.metricBlock}>
              <Text style={styles.metricLabel}>Pace</Text>
              <Text style={styles.metricValue}>{currentMetrics.pace}</Text>
            </View>
          </View>
          {runError && <Text style={styles.errorText}>{runError}</Text>}
          {permissionStatus === 'denied' && !runError && (
            <Text style={styles.warningText}>
              Autorize o GPS para permitir o cálculo de distância.
            </Text>
          )}
          <TouchableOpacity
            style={[
              styles.primaryButton,
              runState !== 'running' && isRequestingLocation && styles.primaryButtonDisabled,
            ]}
            onPress={runState === 'running' ? finishRun : startRun}
            disabled={runState !== 'running' && isRequestingLocation}
          >
            <Text style={styles.primaryButtonText}>
              {runState === 'running'
                ? 'Encerrar corrida'
                : isRequestingLocation
                ? 'Conectando GPS...'
                : 'Iniciar corrida'}
            </Text>
          </TouchableOpacity>
          <Text style={styles.runHint}>{runHint}</Text>
          {pendingRun && (
            <View style={styles.saveRow}>
              <Text style={styles.saveLabel}>Salvar esta corrida no histórico?</Text>
              <TouchableOpacity
                style={[styles.secondaryButton, styles.saveButton]}
                onPress={handleSaveRun}
                disabled={isSavingRun}
              >
                <Text style={styles.secondaryButtonText}>
                  {isSavingRun ? 'Salvando...' : 'Salvar corrida'}
                </Text>
              </TouchableOpacity>
              {historyError && <Text style={styles.errorText}>{historyError}</Text>}
            </View>
          )}
        </View>

        <View style={styles.statsRow}>
          {liveStats.map((stat) => (
            <View key={stat.label} style={styles.statCard}>
              <Text style={styles.statValue}>{stat.value}</Text>
              <Text style={styles.statLabel}>{stat.label}</Text>
            </View>
          ))}
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Seu desempenho</Text>
            <Text style={styles.sectionAction}>Últimos 7 dias</Text>
          </View>

          <View style={styles.performanceCard}>
            <View style={styles.performanceRow}>
              <View>
                <Text style={styles.perfLabel}>Última corrida</Text>
                <Text style={styles.perfValue}>8,2 km • 5:28/km</Text>
              </View>
              <Text style={styles.perfTrend}>+7% semana</Text>
            </View>
            <View style={styles.barTrack}>
              <View style={styles.barFill} />
            </View>
            <Text style={styles.perfNote}>Meta semanal: 30 km</Text>
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Atividade da crew</Text>
            <Text style={styles.sectionAction}>Ver ranking</Text>
          </View>
          {activitiesMock.map((activity) => (
            <View key={activity.id} style={styles.activityCard}>
              <View>
                <Text style={styles.activityName}>
                  {activity.mood} {activity.athlete}
                </Text>
                <Text style={styles.activityDetails}>
                  {activity.distance} • {activity.pace}
                </Text>
              </View>
              <View style={styles.badge}>
                <Text style={styles.badgeText}>+ XP</Text>
              </View>
            </View>
          ))}
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Próximas provas</Text>
            <Text style={styles.sectionAction}>Ver calendário</Text>
          </View>
          {racesMock.map((race) => (
            <View key={race.id} style={styles.raceCard}>
              <View>
                <Text style={styles.raceTitle}>{race.title}</Text>
                <Text style={styles.raceDistance}>{race.distance}</Text>
              </View>
              <View style={styles.raceDate}>
                <Text style={styles.raceDateText}>{race.date}</Text>
              </View>
            </View>
          ))}
        </View>
      </>
    );
  };

  if (isLoadingUser) {
    return (
      <SafeAreaView style={[styles.safeArea, styles.centeredContainer]}>
        <StatusBar style="light" />
        <ActivityIndicator color={THEME.accent} size="large" />
        <Text style={styles.loadingText}>Carregando seus dados...</Text>
      </SafeAreaView>
    );
  }

  if (!userProfile) {
    return (
      <SafeAreaView style={[styles.safeArea, styles.loginContainer]}>
        <StatusBar style="light" />
        <View style={styles.loginCard}>
          <Text style={styles.loginTitle}>Entrar no TrainUP</Text>
          <Text style={styles.loginSubtitle}>
            Personalize a experiência informando seus dados
          </Text>
          <TextInput
            style={styles.input}
            placeholder="Digite seu nome"
            placeholderTextColor="#7B7997"
            value={nameInput}
            onChangeText={setNameInput}
            autoCapitalize="words"
            returnKeyType="done"
          />
          <TextInput
            style={styles.input}
            placeholder="Digite seu e-mail"
            placeholderTextColor="#7B7997"
            value={emailInput}
            onChangeText={setEmailInput}
            autoCapitalize="none"
            keyboardType="email-address"
            returnKeyType="next"
          />
          <TextInput
            style={styles.input}
            placeholder="Crie uma senha"
            placeholderTextColor="#7B7997"
            value={passwordInput}
            onChangeText={setPasswordInput}
            secureTextEntry
            returnKeyType="done"
          />
          <TouchableOpacity
            style={[
              styles.primaryButton,
              (isSavingName ||
                nameInput.trim().length < 2 ||
                !emailInput.trim().includes('@') ||
                passwordInput.trim().length < 4) &&
                styles.primaryButtonDisabled,
            ]}
            onPress={handleLogin}
            disabled={
              isSavingName ||
              nameInput.trim().length < 2 ||
              !emailInput.trim().includes('@') ||
              passwordInput.trim().length < 4
            }
          >
            <Text style={styles.primaryButtonText}>
              {isSavingName ? 'Salvando...' : 'Continuar'}
            </Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar style="light" />
      <ScrollView key={currentPage} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.pageLabel}>{headerCopy.title}</Text>
            <Text style={styles.greeting}>{headerCopy.greeting}</Text>
            <Text style={styles.subtitle}>{headerCopy.subtitle}</Text>
          </View>
          <View style={styles.avatar}>
            <Text style={styles.avatarInitials}>{avatarInitials}</Text>
          </View>
        </View>

        {renderPageContent()}
      </ScrollView>

      <View style={styles.paginationContainer}>
        {PAGES.map((page, index) => (
          <TouchableOpacity
            key={page}
            style={styles.dotWrapper}
            onPress={() => setCurrentPage(index)}
            accessibilityRole="button"
            accessibilityLabel={`Ir para ${page}`}
          >
            <View
              style={[
                styles.paginationDot,
                currentPage === index && styles.paginationDotActive,
              ]}
            />
            <Text
              style={[
                styles.dotCaption,
                currentPage === index && styles.dotCaptionActive,
              ]}
            >
              {page}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: THEME.background,
  },
  scrollContent: {
    padding: 24,
    paddingBottom: 40,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  pageLabel: {
    color: THEME.accent,
    fontSize: 12,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  greeting: {
    fontSize: 20,
    fontWeight: '600',
    color: THEME.text,
  },
  subtitle: {
    color: THEME.muted,
    marginTop: 4,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: THEME.accentDark,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarInitials: {
    color: THEME.text,
    fontWeight: '700',
  },
  highlightCard: {
    backgroundColor: THEME.card,
    borderRadius: 24,
    padding: 20,
    marginBottom: 20,
  },
  cardLabel: {
    color: THEME.muted,
    textTransform: 'uppercase',
    letterSpacing: 1,
    fontSize: 12,
  },
  cardTitle: {
    color: THEME.text,
    fontSize: 22,
    fontWeight: '700',
    marginTop: 8,
  },
  primaryButton: {
    backgroundColor: THEME.accent,
    borderRadius: 16,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 18,
  },
  primaryButtonDisabled: {
    opacity: 0.4,
  },
  primaryButtonText: {
    color: '#0E0E12',
    fontWeight: '700',
  },
  runHint: {
    color: THEME.muted,
    marginTop: 10,
  },
  saveRow: {
    marginTop: 16,
    backgroundColor: '#1A1830',
    borderRadius: 16,
    padding: 14,
  },
  saveLabel: {
    color: THEME.text,
    marginBottom: 10,
    fontWeight: '600',
  },
  saveButton: {
    alignSelf: 'flex-start',
  },
  warningText: {
    color: THEME.muted,
    marginTop: 10,
  },
  errorText: {
    color: '#FF6B6B',
    marginTop: 10,
    fontWeight: '600',
  },
  highlightMetricsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
    marginTop: 16,
  },
  metricBlock: {
    flex: 1,
    backgroundColor: '#252338',
    borderRadius: 16,
    padding: 12,
  },
  metricLabel: {
    color: THEME.muted,
    fontSize: 12,
    marginBottom: 6,
  },
  metricValue: {
    color: THEME.text,
    fontSize: 18,
    fontWeight: '700',
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    backgroundColor: THEME.card,
    borderRadius: 18,
    padding: 14,
  },
  statValue: {
    color: THEME.text,
    fontSize: 18,
    fontWeight: '700',
  },
  statLabel: {
    color: THEME.muted,
    marginTop: 6,
  },
  section: {
    marginBottom: 28,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  sectionTitle: {
    color: THEME.text,
    fontSize: 18,
    fontWeight: '600',
  },
  sectionAction: {
    color: THEME.accent,
    fontSize: 13,
  },
  performanceCard: {
    backgroundColor: THEME.card,
    borderRadius: 20,
    padding: 18,
  },
  performanceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  perfLabel: {
    color: THEME.muted,
    marginBottom: 4,
  },
  perfValue: {
    color: THEME.text,
    fontSize: 20,
    fontWeight: '700',
  },
  perfTrend: {
    color: THEME.success,
    fontWeight: '600',
  },
  barTrack: {
    height: 10,
    borderRadius: 999,
    backgroundColor: '#2C2B3F',
    overflow: 'hidden',
  },
  barFill: {
    height: '100%',
    width: '68%',
    borderRadius: 999,
    backgroundColor: THEME.accent,
  },
  perfNote: {
    color: THEME.muted,
    marginTop: 10,
  },
  activityCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: THEME.card,
    padding: 16,
    borderRadius: 18,
    marginBottom: 12,
  },
  activityName: {
    color: THEME.text,
    fontWeight: '600',
  },
  activityDetails: {
    color: THEME.muted,
    marginTop: 4,
  },
  badge: {
    backgroundColor: '#241F3C',
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  badgeText: {
    color: THEME.accent,
    fontWeight: '700',
  },
  raceCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: THEME.card,
    padding: 16,
    borderRadius: 18,
    marginBottom: 12,
  },
  raceTitle: {
    color: THEME.text,
    fontWeight: '600',
  },
  raceDistance: {
    color: THEME.muted,
    marginTop: 4,
  },
  raceDate: {
    borderWidth: 1,
    borderColor: '#2F2850',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
  },
  raceDateText: {
    color: THEME.text,
    fontWeight: '700',
  },
  paginationContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 32,
    paddingVertical: 14,
    borderTopWidth: 1,
    borderTopColor: '#1F1E2C',
    backgroundColor: '#09090C',
  },
  dotWrapper: {
    alignItems: 'center',
    gap: 6,
    flex: 1,
  },
  paginationDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#3A384A',
  },
  paginationDotActive: {
    width: 24,
    backgroundColor: THEME.accent,
  },
  dotCaption: {
    color: THEME.muted,
    fontSize: 12,
  },
  dotCaptionActive: {
    color: THEME.text,
    fontWeight: '600',
  },
  secondaryButton: {
    borderWidth: 1,
    borderColor: '#352B52',
    borderRadius: 999,
    paddingHorizontal: 14,
    paddingVertical: 6,
  },
  secondaryButtonText: {
    color: THEME.accent,
    fontWeight: '600',
  },
  sessionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: THEME.card,
    padding: 16,
    borderRadius: 18,
    marginBottom: 12,
    gap: 14,
  },
  sessionIcon: {
    width: 46,
    height: 46,
    borderRadius: 14,
    backgroundColor: '#241F3C',
    alignItems: 'center',
    justifyContent: 'center',
  },
  sessionEmoji: {
    fontSize: 22,
  },
  sessionInfo: {
    flex: 1,
  },
  sessionTitle: {
    color: THEME.text,
    fontWeight: '600',
  },
  sessionFocus: {
    color: THEME.accent,
    marginTop: 2,
    fontSize: 12,
    textTransform: 'uppercase',
  },
  sessionDetails: {
    color: THEME.muted,
    marginTop: 4,
  },
  sessionDuration: {
    color: THEME.text,
    fontWeight: '700',
  },
  routeCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: THEME.card,
    padding: 16,
    borderRadius: 18,
    marginBottom: 12,
  },
  routeName: {
    color: THEME.text,
    fontWeight: '600',
  },
  routeMeta: {
    color: THEME.muted,
    marginTop: 4,
  },
  recoveryCard: {
    backgroundColor: '#15142B',
    borderRadius: 22,
    padding: 20,
    marginBottom: 40,
  },
  recoveryTitle: {
    color: THEME.text,
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 6,
  },
  recoverySubtitle: {
    color: THEME.muted,
  },
  recoveryHint: {
    color: THEME.accent,
    marginTop: 12,
    fontWeight: '600',
  },
  achievementGrid: {
    flexDirection: 'row',
    gap: 12,
    flexWrap: 'wrap',
  },
  achievementCard: {
    width: '48%',
    backgroundColor: THEME.card,
    borderRadius: 18,
    padding: 16,
    marginBottom: 12,
  },
  achievementIcon: {
    fontSize: 24,
    marginBottom: 10,
  },
  achievementTitle: {
    color: THEME.text,
    fontWeight: '600',
  },
  achievementDetail: {
    color: THEME.muted,
    marginTop: 4,
  },
  historyCard: {
    backgroundColor: THEME.card,
    borderRadius: 18,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  historyTitle: {
    color: THEME.text,
    fontWeight: '600',
  },
  historyMeta: {
    color: THEME.muted,
    marginTop: 4,
  },
  historyPace: {
    color: THEME.accent,
    fontWeight: '700',
  },
  emptyHistoryText: {
    color: THEME.muted,
    marginBottom: 12,
  },
  gearCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: THEME.card,
    padding: 16,
    borderRadius: 18,
    marginBottom: 12,
  },
  gearName: {
    color: THEME.text,
    fontWeight: '600',
  },
  gearStatus: {
    color: THEME.muted,
    marginTop: 4,
  },
  goalCard: {
    backgroundColor: THEME.card,
    borderRadius: 18,
    padding: 16,
    marginBottom: 12,
  },
  goalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  goalLabel: {
    color: THEME.text,
    fontWeight: '600',
  },
  goalValue: {
    color: THEME.accent,
    fontWeight: '700',
  },
  goalTrack: {
    height: 8,
    borderRadius: 999,
    backgroundColor: '#2C2B3F',
    overflow: 'hidden',
  },
  goalFill: {
    height: '100%',
    borderRadius: 999,
    backgroundColor: THEME.accent,
  },
  centeredContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingText: {
    marginTop: 16,
    color: THEME.muted,
  },
  loginContainer: {
    justifyContent: 'center',
    padding: 24,
  },
  loginCard: {
    backgroundColor: THEME.card,
    borderRadius: 26,
    padding: 24,
    gap: 12,
  },
  loginTitle: {
    color: THEME.text,
    fontSize: 24,
    fontWeight: '700',
  },
  loginSubtitle: {
    color: THEME.muted,
  },
  input: {
    backgroundColor: '#161525',
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 14,
    color: THEME.text,
    marginTop: 8,
  },
  logoutButton: {
    borderWidth: 1,
    borderColor: '#463863',
    borderRadius: 16,
    paddingVertical: 12,
    alignItems: 'center',
    marginTop: 16,
  },
  logoutButtonText: {
    color: THEME.muted,
    fontWeight: '600',
  },
});
